package com.bookmanagement.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {
	 private int bookId;
	    private String title;
	    private int authorId;
	    private int genreId;
	    private int pages;
	    private String publishedDate;
		public void setAuthorID(int authorID2) {
			// TODO Auto-generated method stub
			
		}

}
