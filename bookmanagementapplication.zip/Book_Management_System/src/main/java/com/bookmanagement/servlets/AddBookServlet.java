package com.bookmanagement.servlets;

import java.io.IOException;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bookmanagement.dao.BookDAO;
import com.bookmanagement.model.Book;

@WebServlet("/AddBookServlet")
public class AddBookServlet extends HttpServlet {
    private BookDAO bookDAO = new BookDAO(Connection );

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form parameters
        String title = request.getParameter("title");
        int authorID = Integer.parseInt(request.getParameter("authorID"));
        int genreID = Integer.parseInt(request.getParameter("genreID"));
        int pages = Integer.parseInt(request.getParameter("pages"));
        String publishedDate = request.getParameter("publishedDate");

        // Create a new Book object
        Book book = new Book();
        book.setTitle(title);
        book.setAuthorID(authorID);
        book.setGenreID(genreID);
        book.setPages(pages);
        book.setPublishedDate(publishedDate);

        // Add the book to the database
        boolean isSuccess = bookDAO.addBook(book);

        // Redirect or forward based on the result
        if (isSuccess) {
            response.sendRedirect("books"); // Redirect to the book list page
        } else {
            request.setAttribute("error", "Failed to add the book. Please try again.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("add-book.jsp");
            dispatcher.forward(request, response);
        }
    }
}
