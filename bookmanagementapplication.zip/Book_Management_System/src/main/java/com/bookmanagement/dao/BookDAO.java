package com.bookmanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bookmanagement.model.Book;

public class BookDAO {

	private Connection conn;

    public BookDAO(Connection conn) {
        this.conn = conn;
    }

    public List<Book> getAllBooks() throws SQLException {
        String sql = "SELECT * FROM Books";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        List<Book> books = new ArrayList<>();
        while (rs.next()) {
            Book book = new Book();
            book.setBookId(rs.getInt("BookID"));
            book.setTitle(rs.getString("Title"));
            book.setAuthorId(rs.getInt("AuthorID"));
            book.setGenreId(rs.getInt("GenreID"));
            book.setPages(rs.getInt("Pages"));
            book.setPublishedDate(rs.getString("PublishedDate"));
            books.add(book);
        }
        return books;
    }

    public void addBook(Book book) throws SQLException {
        String sql = "INSERT INTO Books (Title, AuthorID, GenreID, Pages, PublishedDate) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, book.getTitle());
        pstmt.setInt(2, book.getAuthorId());
        pstmt.setInt(3, book.getGenreId());
        pstmt.setInt(4, book.getPages());
        pstmt.setString(5, book.getPublishedDate());
        pstmt.executeUpdate();
    }

    public void deleteBook(int bookId) throws SQLException {
        String sql = "DELETE FROM Books WHERE BookID = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, bookId);
        pstmt.executeUpdate();
    }
}
